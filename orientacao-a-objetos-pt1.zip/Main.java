/******************************************************************************
Orientação a objetos pt-1, criar a classe ai a gnt importa 
*******************************************************************************/
//  public class Estudante {
//	    public String nome;
//	    public int idade;
//	    public char sexo;
//	    
//   }

import academy.dev.javacore.introduçaoclasses.dominio.Estudante;

public class Estudante{
    public static void main(String[] args){
        Estudante estudante = new Estudante();
        Estudante estudante2 = new Estudante();
        
        estudante.nome = "Vinicius";
        estudante.idade =18;
        estudante.sexo = 'M';
        
        estudante2.nome = "Danielle";
        estudante2.idade = 19;
        estudante2.sexo = 'F';
        
        System.out.println(estudante.nome);
        System.out.println(estudante.idade);
        System.out.println(estudante.sexo);
        System.out.println(estudante);
        
        System.out.println(estudante2.nome);
        System.out.println(estudante2.idade);
        System.out.println(estudante2.sexo);
        System.out.println(estudante2);
    }   
}






