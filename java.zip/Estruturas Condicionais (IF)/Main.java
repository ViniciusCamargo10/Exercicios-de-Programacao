/******************************************************************************
Estruturas Condicionais
*******************************************************************************/
public class Main {
    public static void main(String[] args){
        int idade = 15;
        boolean isAutorizadoComprarBebida = idade >= 18;
        
        if(isAutorizadoComprarBebida){
            System.out.println("Autorizado");
        }else{
            System.out.println("Negado");
        }
        
        int idade1 = 17;
        if (idade1 < 15){
            System.out.println("Categoria Infantil");
        }else if (idade1 >= 15 && idade1 <18){
            System.out.println("Categoria Juvenil");
        }else{
            System.out.println("Categoria Adulto");
        }
        
        // Doar se salario for 5000 pra cima 
        
        double salario = 5000;
        String mensagemDoar = "Eu vou doar 500 reais";
        String mensagemNaoDoar = "Eu não vou doar";
        //Operador Ternario condição ? verdadeiro : falso
        //String resultado = salario >= 5000 ? mensagemDoar : mensagemNaoDoar;
        
        if (salario >= 5000){
          resultado = mensagemDoar;
         }else{
        resultado = mensagemNaoDoar;
        }
        System.out.println(resultado);
        
        }
        
   }
