/******************************************************************************
Aula 1 - Variavel e estrutura basica
*******************************************************************************/
public class Main {
    public static void main(String[] args){
        // int, double, float, char, string, byte, short, long, boolean
        // cash força a variavel: (float) 2500.0D eu forço um double em um float 
        
        int idade = 10;
        long numeroGrande = 100000L;
        double salarioDouble = 2000.0;
        float salarioFloat = 2500.0f;
        byte idadeByte = 10;
        short idadeShort = 10;
        boolean verdadeiro = true;
        char caractere = 'M';
        String nome = "Vinicius Camargo";
        
        System.out.println("A idade é: " +idade+ " anos");
        System.out.println(true);
        System.out.println("Meu nome é: "+nome);
    }
}

