// Herança simples
class A {
    // Classe A vazia
}

class B extends A {
    // Classe B herda de A
}

// Herança múltipla não é suportada diretamente em Java
// É comum usar interfaces para conseguir algo semelhante

interface D {
    // Interface D vazia
}

interface E extends D {
    // Interface E herda de D
}

class F extends A {
    // Classe F herda de A
    // Não é possível herdar de B simultaneamente em Java
}

// Classe Veiculo
class Veiculo {
    private String cor;
    private String placa;
    private int numRodas;

    public Veiculo(String cor, String placa, int numRodas) {
        this.cor = cor;
        this.placa = placa;
        this.numRodas = numRodas;
    }

    public void ligarMotor() {
        System.out.println("Ligando o motor...");
    }

    public String getCor() {
        return cor;
    }

    public String getPlaca() {
        return placa;
    }

    public int getNumRodas() {
        return numRodas;
    }
}

// Classe Motocicleta
class Motocicleta extends Veiculo {
    public Motocicleta(String cor, String placa, int numRodas) {
        super(cor, placa, numRodas);
    }
}

// Classe Carro
class Carro extends Veiculo {
    public Carro(String cor, String placa, int numRodas) {
        super(cor, placa, numRodas);
    }

    @Override
    public String toString() {
        return "Cor: " + getCor() + ", Placa: " + getPlaca() + ", Numero de rodas: " + getNumRodas();
    }
}

// Classe Caminhão
class Caminhao extends Veiculo {
    public Caminhao(String cor, String placa, int numRodas) {
        super(cor, placa, numRodas);
    }
}

public class Main {
    public static void main(String[] args) {
        Carro carro = new Carro("roxo", "abc", 4);
        System.out.println(carro);
        carro.ligarMotor();
    }
}
