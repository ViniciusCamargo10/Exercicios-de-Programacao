/******************************************************************************
Polimorfismo
*******************************************************************************/
//Resumo
//Sobrecarga de métodos: Mesma classe, métodos com o mesmo nome, mas diferentes assinaturas.
//Sobrescrita de métodos: Subclasses fornecem implementações específicas de métodos definidos na superclasse.

class Operacao {
    // Método para somar dois inteiros
    int soma(int a, int b) {
        return a + b;
    }

    // Método para somar três inteiros
    int soma(int a, int b, int c) {
        return a + b + c;
    }

    // Método para somar dois números em ponto flutuante
    double soma(double a, double b) {
        return a + b;
    }
}

public class Main {
    public static void main(String[] args) {
        Operacao op = new Operacao();
        
        System.out.println(op.soma(2, 3)); // Chama soma(int, int)
        System.out.println(op.soma(2, 3, 4)); // Chama soma(int, int, int)
        System.out.println(op.soma(2.5, 3.5)); // Chama soma(double, double)
    }
}
System.out.println("-------------------------------");


// Superclasse
class Animal {
    void som() {
        System.out.println("O animal faz um som");
    }
}

// Subclasse
class Cachorro extends Animal {
    @Override
    void som() {
        System.out.println("O cachorro late");
    }
}

// Outra Subclasse
class Gato extends Animal {
    @Override
    void som() {
        System.out.println("O gato mia");
    }
}

public class Main {
    public static void main(String[] args) {
        Animal meuAnimal;
        
        meuAnimal = new Cachorro();
        meuAnimal.som(); // Chama o método som() da classe Cachorro

        meuAnimal = new Gato();
        meuAnimal.som(); // Chama o método som() da classe Gato
    }
}
