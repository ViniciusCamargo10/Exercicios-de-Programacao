/******************************************************************************
List, Set, Map
*******************************************************************************/
Resumo
// List: Uso quando você precisa de uma coleção ordenada e permite elementos duplicados. 
// Acessa elementos por índice. Implementações comuns incluem ArrayList e LinkedList.
// Set: Uso quando você precisa de uma coleção que não permite elementos duplicados. 
// Não garante ordem específica (exceto LinkedHashSet e TreeSet). 
// Implementações comuns incluem HashSet, LinkedHashSet, e TreeSet.
// Map: Uso quando você precisa de uma coleção de pares chave-valor, onde cada chave é única. 
// Implementações comuns incluem HashMap, LinkedHashMap, e TreeMap.

// List 

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Criação de uma lista
        List<String> lista = new ArrayList<>();

        // Adição de elementos
        lista.add("Maçã");
        lista.add("Banana");
        lista.add("Laranja");

        // Acesso a elementos por índice
        System.out.println("Primeiro elemento: " + lista.get(0));

        // Iteração sobre a lista
        for (String fruta : lista) {
            System.out.println(fruta);
        }

        // Remoção de elemento
        lista.remove("Banana");

        System.out.println("Após remoção:");
        for (String fruta : lista) {
            System.out.println(fruta);
        }
    }
}

// Set

import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        // Criação de um conjunto
        Set<String> conjunto = new HashSet<>();

        // Adição de elementos
        conjunto.add("Maçã");
        conjunto.add("Banana");
        conjunto.add("Laranja");
        conjunto.add("Maçã"); // Tentativa de adicionar duplicata

        // Iteração sobre o conjunto
        for (String fruta : conjunto) {
            System.out.println(fruta);
        }

        // Remoção de elemento
        conjunto.remove("Banana");

        System.out.println("Após remoção:");
        for (String fruta : conjunto) {
            System.out.println(fruta);
        }
    }
}

// Map

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Criação de um mapa
        Map<String, Integer> mapa = new HashMap<>();

        // Adição de pares chave-valor
        mapa.put("Maçã", 3);
        mapa.put("Banana", 2);
        mapa.put("Laranja", 5);

        // Acesso a valores por chave
        System.out.println("Quantidade de maçãs: " + mapa.get("Maçã"));

        // Iteração sobre o mapa
        for (Map.Entry<String, Integer> entrada : mapa.entrySet()) {
            System.out.println(entrada.getKey() + ": " + entrada.getValue());
        }

        // Remoção de par chave-valor
        mapa.remove("Banana");

        System.out.println("Após remoção:");
        for (Map.Entry<String, Integer> entrada : mapa.entrySet()) {
            System.out.println(entrada.getKey() + ": " + entrada.getValue());
        }
    }
}
