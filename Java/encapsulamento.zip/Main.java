/******************************************************************************
Encapsulamento
*******************************************************************************/
// Getters são usados quando você precisa ler o valor de um atributo.
// Setters são usados quando você precisa modificar o valor de um atributo.

public class Pessoa {
    private String nome;
    private int idade;

    // Getter para 'nome'
    public String getNome() {
        return nome;
    }

    // Setter para 'nome'
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Getter para 'idade'
    public int getIdade() {
        return idade;
    }

    // Setter para 'idade'
    public void setIdade(int idade) {
        if (idade > 0) { // Adicionando validação
            this.idade = idade;
        } else {
            System.out.println("Idade inválida");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        
        // Usando setters para modificar os atributos
        p.setNome("João");
        p.setIdade(30);
        
        // Usando getters para acessar os atributos
        System.out.println("Nome: " + p.getNome());
        System.out.println("Idade: " + p.getIdade());
    }
}
