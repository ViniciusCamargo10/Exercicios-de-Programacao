/******************************************************************************
Exercicio Variavel
*******************************************************************************/
public class Main
{
    public static void main(String[] args) {
        String nome = "Vinicius";
        String cidade = "São Paulo";
        int salario = 1417;
        String data = "12-07-2024"; // A data é uma string para preservar o formato
        String relatorio = "Eu " + nome + " moro na cidade de: " + cidade + " recebo atualmente o salario de: " + salario + " na data de: " + data;
        System.out.println(relatorio);
    }
}
