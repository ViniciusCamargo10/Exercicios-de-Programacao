/******************************************************************************
Aula 2 - Operadores 
*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 20;
		int resultado = num1 + num2;
		int num3 = 5;
		int num4 = 4;
		int resultadoSubtracao = num3 - num4;
		double num5 = 35.5;
		double num6 = 21.3;
		double resultadoMultiplicacao = num5 * num6;
		int num7 = 21;
		int num8 = 3;
		int resultadoDivisao = num7 / num8;
	    
	    int resto = 20 % 2;// se for zero é par
	    System.out.println(resto);
	    
	   // Operador Logico: < > <= >= != sempre retorna valor boleano
	   
        Boolean isDezMaiorQueVinte = 10 > 20;
        Boolean isDezDiferenteQueVinte = 10 != 20;
	    
	    System.out.println(isDezMaiorQueVinte);
	    System.out.println(isDezDiferenteQueVinte);
		System.out.println("A soma entre os numeros 1 e 2 é: "+resultado);
		System.out.println("A soma entre os numeros 3 e 4 é: "+resultadoSubtracao);
		System.out.println("A multiplicação entre os numeros 5 e 6 é: "+resultadoMultiplicacao);
		System.out.println("A soma entre os numeros 7 e 8 é: "+resultadoDivisao);
		
		
		// && (AND) || (OR) ! (NOT)
		
		int idade = 35;
		float salario = 3500F;
		Boolean isDentroDaLeiMaiorQueTrinta = idade > 30 && salario >= 4612; 
		Boolean isDentroDaLeiMenorQueTrinta = idade < 30 && salario >= 3381;
		System.out.println("isDentroDaLeiMaiorQueTrinta "+isDentroDaLeiMaiorQueTrinta);
		System.out.println("isDentroDaLeiMenorQueTrinta "+isDentroDaLeiMenorQueTrinta);
		
		double valorTotalContaCorrente = 200;
		double valorTotalContaPoupanca = 6000;
		float valorXbox = 5000f;
		Boolean isXboxCompravel = valorTotalContaCorrente > valorXbox || valorTotalContaPoupanca > valorXbox;
		System.out.println(isXboxCompravel);
		
		// = += -+ *= /= %= formas de abreviar
		
		double bonus = 1800;
		bonus += 1000;
		System.out.println(bonus);
		
		// ++ -- / na frente primeiro encrementa... atras executa e depois encrementa 
		
		int contador = 0 ;
		contador++;
		System.out.println(contador);
		
	}
}

    