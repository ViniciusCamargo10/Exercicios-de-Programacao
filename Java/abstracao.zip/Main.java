/******************************************************************************
Abstração
*******************************************************************************/
// Classes Abstratas
// Uma classe abstrata é uma classe que não pode ser instanciada diretamente. 
// Ela pode ter métodos abstratos (sem implementação) e métodos concretos (com implementação). 
// As subclasses que herdam da classe abstrata devem fornecer implementações para todos os métodos abstratos.

abstract class Animal {
    // Método abstrato (sem implementação)
    abstract void fazerSom();
    
    // Método concreto (com implementação)
    void dormir() {
        System.out.println("O animal está dormindo");
    }
}

class Cachorro extends Animal {
    @Override
    void fazerSom() {
        System.out.println("O cachorro late");
    }
}

class Gato extends Animal {
    @Override
    void fazerSom() {
        System.out.println("O gato mia");
    }
}

public class Main {
    public static void main(String[] args) {
        Animal meuCachorro = new Cachorro();
        meuCachorro.fazerSom(); // Saída: O cachorro late
        meuCachorro.dormir(); // Saída: O animal está dormindo

        Animal meuGato = new Gato();
        meuGato.fazerSom(); // Saída: O gato mia
        meuGato.dormir(); // Saída: O animal está dormindo
    }
}

System.out.println("-------------------------------");

// Interface exemplo: 
abstract class Animal {
    // Método abstrato (sem implementação)
    abstract void fazerSom();
    
    // Método concreto (com implementação)
    void dormir() {
        System.out.println("O animal está dormindo");
    }
}

class Cachorro extends Animal {
    @Override
    void fazerSom() {
        System.out.println("O cachorro late");
    }
}

class Gato extends Animal {
    @Override
    void fazerSom() {
        System.out.println("O gato mia");
    }
}

public class Main {
    public static void main(String[] args) {
        Animal meuCachorro = new Cachorro();
        meuCachorro.fazerSom(); // Saída: O cachorro late
        meuCachorro.dormir(); // Saída: O animal está dormindo

        Animal meuGato = new Gato();
        meuGato.fazerSom(); // Saída: O gato mia
        meuGato.dormir(); // Saída: O animal está dormindo
    }
}

