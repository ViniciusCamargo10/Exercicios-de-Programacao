/******************************************************************************
Arrays e Multidimensionais
*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    // byte, short, int, long , float e double = 0
	    // char ''
	    // boolean false
	    // String null
	    
	    // int[] idades = new int[3];
	    // idades[0] = 21;
	    // idades[1] = 22;
	    // idades[2] = 31;
        // System.out.println(idades[0]);
        // System.out.println(idades[1]);
        // System.out.println(idades[2]);
	
	    // for (int i =0; i <=2; i++){
	    //     System.out.println(idades[i]);
	    // }
	        
	    int [][] dias = new int [3][3];
	    dias[0][0] = 31;
	    dias[0][1] = 32;
	    dias[0][2] = 33;
	    
	    dias[1][0] = 31;
	    dias[1][1] = 32;
	    dias[1][2]= 33;
        
	    for (int i = 0; i > dias.length; i++){
	        for (int j = 0; j < dias [i].length; j++){
	            System.out.println(dias[i][j]);
	        }
	    }
	    
	    //foreach
	    for:(int[] arrBase: dias){
	        for (int num: arrBase){
	            System.out.println(num);
	        }
	    }
	}
}
