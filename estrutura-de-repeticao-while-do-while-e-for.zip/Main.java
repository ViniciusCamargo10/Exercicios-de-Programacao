/******************************************************************************
Estrutura de repetição while, do while e for 
*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    // condição precisa ser verdadeira
	    int count = 12;
	    while (count < 10){
	        System.out.println(count);
	        count += 1;
	        
	    }
	    // se for verdadeiro ou falso pelo menos vai imprimir uma vez
	    do {
	       System.out.println("Dentro do while");
	   }while (count < 10);
	    
	    // mais usado pra contagem
	    
	    for (int i=0;i<10;i++){
	        System.out.println("For"+i);
	    }
	    
	    
	    // imprima todos os numeros pares ate 100
	    
	    for (int i=0; i <= 1000;i++){
	        if(i % 2 == 0){
	            System.out.println(i);
	        
	        }
	    int valorMax = 50;   
	    for (int j=0; j <= valorMax; j++){
	        if (j > 25){
	            break;
	        }
	       System.out.println(j); 
	    }
	        
	    }
	    
	}
}
